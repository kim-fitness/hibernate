/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */

package org.hibernate.dialect.sqlanywhere;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.hibernate.engine.jdbc.batch.internal.AbstractBatchImpl;
import org.hibernate.engine.jdbc.batch.internal.NonBatchingBatch;
import org.hibernate.engine.jdbc.batch.spi.BatchKey;
import org.hibernate.engine.jdbc.spi.JdbcCoordinator;
import org.hibernate.internal.CoreMessageLogger;
import org.jboss.logging.Logger;

/**
 * An implementation of {@link org.hibernate.engine.jdbc.batch.spi.Batch} which does not perform batching.
 * It simply executes each statement as it is encountered.
 * Adapted from Hibernate 4 for Hibernate 5.x compatibility.
 *
 * @author Steve Ebersole
 */
public class JConnNonBatchingBatch extends AbstractBatchImpl {

	private static final CoreMessageLogger LOG = Logger.getMessageLogger( CoreMessageLogger.class, NonBatchingBatch.class.getName() );

	protected JConnNonBatchingBatch(BatchKey key, JdbcCoordinator jdbcCoordinator) {
		super( key, jdbcCoordinator );
	}

	@Override
	public void addToBatch() {
		// H5: notifyObserversImplicitExecution() was removed from AbstractBatchImpl.
		for ( Map.Entry<String,PreparedStatement> entry : getStatements().entrySet() ) {
			try {
				final PreparedStatement statement = entry.getValue();
				final int rowCount = statement.executeUpdate();
				// H5: verifyOutcome() now takes 4 args: (rowCount, statement, batchPosition, sql)
				getKey().getExpectation().verifyOutcome( rowCount, statement, 0, entry.getKey() );
				try {
					statement.close();
				}
				catch (SQLException e) {
					LOG.debug( "Unable to close non-batched batch statement", e );
				}
			}
			catch ( SQLException e ) {
				LOG.debug( "SQLException escaped proxy", e );
				throw sqlExceptionHelper().convert( e, "could not execute batch statement", entry.getKey() );
			}
		}
		getStatements().clear();
	}

	@Override
	protected void doExecuteBatch() {
		// nothing to do
	}
}
