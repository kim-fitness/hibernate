/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */

package org.hibernate.dialect.sqlanywhere;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.jdbc.batch.internal.AbstractBatchImpl;
import org.hibernate.engine.jdbc.batch.internal.BatchingBatch;
import org.hibernate.engine.jdbc.batch.spi.BatchKey;
import org.hibernate.engine.jdbc.spi.JdbcCoordinator;
import org.hibernate.engine.spi.ExecuteUpdateResultCheckStyle;
import org.hibernate.internal.CoreMessageLogger;
import org.hibernate.jdbc.Expectations;
import org.jboss.logging.Logger;

/**
 * A {@link org.hibernate.engine.jdbc.batch.spi.Batch} implementation which does batching based on a given size.
 * Once the batch size is reached for a statement in the batch, the entire batch is implicitly executed.
 * Adapted from Hibernate 4 for Hibernate 5.x compatibility.
 *
 * @author Steve Ebersole
 */
public class JConnBatchingBatch extends AbstractBatchImpl {

	private static final CoreMessageLogger LOG = Logger.getMessageLogger( CoreMessageLogger.class, BatchingBatch.class.getName() );

	// IMPL NOTE : Until HHH-5797 is fixed, there will only be 1 statement in a batch

	private final int batchSize;
	private int batchPosition;
	private int statementPosition;

	public JConnBatchingBatch(
			BatchKey key,
			JdbcCoordinator jdbcCoordinator,
			int batchSize) {
		super( key, jdbcCoordinator );
		if ( ! key.getExpectation().canBeBatched() ) {
			throw new HibernateException( "attempting to batch an operation which cannot be batched" );
		}
		this.batchSize = batchSize;
	}

	private String currentStatementSql;
	private PreparedStatement currentStatement;

	@Override
	public PreparedStatement getBatchStatement(String sql, boolean callable) {
		currentStatementSql = sql;
		currentStatement = super.getBatchStatement( sql, callable );
		return currentStatement;
	}

	@Override
	public void addToBatch() {
		try {
			currentStatement.addBatch();
		}
		catch ( SQLException e ) {
			LOG.debugf( "SQLException escaped proxy", e );
			throw sqlExceptionHelper().convert( e, "could not perform addBatch", currentStatementSql );
		}
		statementPosition++;
		if ( statementPosition >= getKey().getBatchedStatementCount() ) {
			batchPosition++;
			if ( batchPosition == batchSize ) {
				// H5: notifyObserversImplicitExecution() was removed from AbstractBatchImpl.
				// Execution notification is now handled internally by the framework.
				performExecution();
				batchPosition = 0;
			}
			statementPosition = 0;
		}
	}

	@Override
	protected void doExecuteBatch() {
		if ( batchPosition == 0 ) {
			LOG.debug( "No batched statements to execute" );
		}
		else {
			LOG.debugf( "Executing batch size: %s", batchPosition );
			performExecution();
		}
	}

	private void performExecution() {
		try {
			for ( Map.Entry<String,PreparedStatement> entry : getStatements().entrySet() ) {
				try {
					final PreparedStatement statement = entry.getValue();
					checkRowCounts( statement.executeBatch(), statement );
				}
				catch ( SQLException e ) {
					LOG.debug( "SQLException escaped proxy", e );
					throw sqlExceptionHelper().convert( e, "could not perform addBatch", entry.getKey() );
				}
			}
		}
		catch ( RuntimeException re ) {
			LOG.unableToExecuteBatch( re, re.getMessage() );
			throw re;
		}
		finally {
			batchPosition = 0;
		}
	}

	// jConnect override for checking row counts, since .executeBatch doesn't return a standard int[] list.
	// H5: Expectations.appropriateExpectation() was removed; use Expectations.NONE directly.
	// H5: verifyOutcome() now takes 4 args: (rowCount, statement, batchPosition, sql)
	private void checkRowCounts(int[] rowCounts, PreparedStatement ps) throws SQLException, HibernateException {
		int numberOfRowCounts = rowCounts.length;
		if ( numberOfRowCounts != batchPosition ) {
			LOG.unexpectedRowCounts();
		}
		for ( int i = 0; i < numberOfRowCounts; i++ ) {
			Expectations.NONE.verifyOutcome( rowCounts[i], ps, i, currentStatementSql );
		}
	}
}
