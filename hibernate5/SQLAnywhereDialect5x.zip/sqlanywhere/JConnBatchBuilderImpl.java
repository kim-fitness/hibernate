/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * License: GNU Lesser General Public License (LGPL), version 2.1 or later.
 * See the lgpl.txt file in the root directory or <http://www.gnu.org/licenses/lgpl-2.1.html>.
 */

package org.hibernate.dialect.sqlanywhere;

import java.util.Map;

import org.hibernate.cfg.Environment;
import org.hibernate.engine.jdbc.batch.internal.BatchingBatch;
import org.hibernate.engine.jdbc.batch.internal.NonBatchingBatch;
import org.hibernate.engine.jdbc.batch.spi.Batch;
import org.hibernate.engine.jdbc.batch.spi.BatchBuilder;
import org.hibernate.engine.jdbc.batch.spi.BatchKey;
import org.hibernate.engine.jdbc.spi.JdbcCoordinator;
import org.hibernate.internal.CoreMessageLogger;
import org.hibernate.internal.util.config.ConfigurationHelper;
import org.hibernate.service.spi.Configurable;
import org.jboss.logging.Logger;

/**
 * A builder for {@link Batch} instances.
 * Adapted from Hibernate 4 for Hibernate 5.x compatibility.
 *
 * @author Steve Ebersole
 */
public class JConnBatchBuilderImpl implements BatchBuilder, Configurable {

	private static final CoreMessageLogger LOG = Logger.getMessageLogger( CoreMessageLogger.class, JConnBatchBuilderImpl.class.getName() );

	private int size;

	public JConnBatchBuilderImpl() {
	}

	// H5: Configurable.configure() still uses raw Map (same as H4) — generic Map<String,Object>
	// would cause a name clash. Keep raw Map to match the interface contract.
	@Override
	@SuppressWarnings("rawtypes")
	public void configure(Map configurationValues) {
		size = ConfigurationHelper.getInt( Environment.STATEMENT_BATCH_SIZE, configurationValues, size );
	}

	public JConnBatchBuilderImpl(int size) {
		this.size = size;
	}

	public void setJdbcBatchSize(int size) {
		this.size = size;
	}

	@Override
	public Batch buildBatch(BatchKey key, JdbcCoordinator jdbcCoordinator) {
		LOG.tracef( "Building batch [size=%s]", size );
		return size > 1
				? new JConnBatchingBatch( key, jdbcCoordinator, size )
				: new JConnNonBatchingBatch( key, jdbcCoordinator );
	}

	// H5: getManagementDomain(), getManagementServiceType(), getManagementBean()
	// were removed from BatchBuilder interface in Hibernate 5 — no longer implemented.
}
