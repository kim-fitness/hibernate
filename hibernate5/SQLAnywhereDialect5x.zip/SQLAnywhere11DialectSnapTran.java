/**
 * SQL Dialect for SQL Anywhere 11 with Snapshot Isolation 
 * for the Hibernate 5.x distribution
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Support: http://sqlanywhere-forum.sybase.com/
 *          http://www.sap.com/services-and-support/
 *
 */
 
package org.hibernate.dialect;

/**
 * @author 		SAP AG or an SAP affiliate company
 * @version 5.0
 * @since			2013-01-22
 */
public class SQLAnywhere11DialectSnapTran extends SQLAnywhere11Dialect {
	/**
	 * Determine ANSI isolation semantics for writing blocking reading
	 *
	 * Snapshot isolation writers do not block readers
	 */
	public boolean doesReadCommittedCauseWritersToBlockReaders() {
		return false;
	}
	
	/**
	 * Determine ANSI isolation semantics for reading blocking writing
	 *
	 * Snapshot isolation readers do not block writers
	 */
	public boolean doesRepeatableReadCauseReadersToBlockWriters() {
		return false;
	}
}